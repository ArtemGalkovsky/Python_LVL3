﻿using Sample.Data.Models;
using System.Data.Entity;
using Sample.Data.Migrations;

namespace Sample.Data.Context
{
    [DbConfigurationType(typeof(DbConfig))]
    public class BookContext : DbContext
    {
        public BookContext()
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<BookContext, Configuration>());
        }

        public DbSet<BookDb> Books { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            var entity = modelBuilder.Entity<BookDb>();

            entity.HasKey(x => x.Id);
            entity.Property(x => x.Title).IsRequired()
                .HasMaxLength(255).IsUnicode();

            entity.Property(x => x.Price).IsRequired();
        }
    }
}
