using System.Collections.Generic;
using Sample.Data.Models;

namespace Sample.Data.Migrations
{
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<Context.BookContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(Sample.Data.Context.BookContext context)
        {
            if (context.Books.Any()) return;

            context.Books.AddRange(new List<BookDb>()
           {
               new BookDb()
               {
                   Title = "Book 1",
                   Price = 10.0
               },
               new BookDb()
               {
                   Title = "Book 2",
                   Price = 20.0
               }
           });

            context.SaveChanges();
        }
    }
}
