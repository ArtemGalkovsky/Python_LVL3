﻿using Ninject.Modules;
using Sample.Data.Context;

namespace Sample.Data
{
    public class DataModule : NinjectModule
    {
        public override void Load()
        {
            Bind<BookContext>().ToSelf();
        }
    }
}
