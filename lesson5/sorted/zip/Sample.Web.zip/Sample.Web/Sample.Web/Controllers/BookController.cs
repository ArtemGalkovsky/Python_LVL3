﻿using Sample.Logic.Services;
using Sample.Models;
using Swashbuckle.Swagger.Annotations;
using System;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using FluentValidation;
using FluentValidation.WebApi;

namespace Sample.Web.Controllers
{
    [RoutePrefix("api/books")]
    public class BookController : ApiController
    {
        private readonly IBookService _bookService;
        private readonly IValidator<Book> _validator;

        public BookController(IBookService bookService, IValidator<Book> validator)
        {
            _bookService = bookService;
            _validator = validator;
        }

        [HttpGet, Route("{id}")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Ivalid paramater format")]
        [SwaggerResponse(HttpStatusCode.NotFound, "Book doesn't exists")]
        [SwaggerResponse(HttpStatusCode.OK, "Book found", typeof(Book))]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Something wrong")]
        public async Task<IHttpActionResult> GetById(string id)
        {
            //validate id
            if (string.IsNullOrEmpty(id) || !Guid.TryParse(id, out var _))
            {
                return BadRequest();
            }

            try
            {
                var result = await _bookService.GetByIdAsync(id);
                return result == null ? NotFound() : (IHttpActionResult)Ok(result);
            }
            catch (InvalidOperationException ex)
            {
                return InternalServerError(ex);
            }
        }

        [HttpGet, Route("")]
        public async Task<IHttpActionResult> GetAll()
        {
            var result = await _bookService.GetAllAsync();
            return result == null ? NotFound() : (IHttpActionResult)Ok(result);
        }

        [HttpPost, Route("")]
        public IHttpActionResult Create([FromBody, CustomizeValidator(RuleSet = "AddBook, default")]Book book)
        {
            // validate book here
            var result = _validator.Validate(book);
            if (!result.IsValid)
            {
                return BadRequest(result.Errors.Select(x => x.ErrorMessage).Aggregate((a, b) => $"{a} {b}"));
            }

            return Ok(BookStorage.Add(book));
        }

        [HttpPut, Route("")]
        public IHttpActionResult Update([FromBody, CustomizeValidator(RuleSet = "UpdateBook,default")]Book book)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            return Ok();
        }

        //[HttpDelete, Route("{id}")]
        //public IHttpActionResult Delete(string id)
        //{

        //}

        protected override void Dispose(bool disposing)
        {
            this._bookService.Dispose();
            base.Dispose(disposing);
        }
    }
}
