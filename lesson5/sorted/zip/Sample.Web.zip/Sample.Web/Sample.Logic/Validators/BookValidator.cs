﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentValidation;
using FluentValidation.Attributes;
using FluentValidation.Validators;
using Sample.Logic.Services;
using Sample.Models;

namespace Sample.Logic.Validators
{
    public class BookValidator : AbstractValidator<Book>
    {
        public BookValidator(IBookService service)
        {
            CascadeMode = CascadeMode.StopOnFirstFailure;

            RuleSet("AddBook", () =>
            {
                RuleFor(x => x.Id).Must(x => string.IsNullOrEmpty(x)).WithMessage("Id must be empty or null");
                RuleFor(x => x.Title).MustAsync((async (title, token) => !(await service.ExistsAsync(title).ConfigureAwait(false))));
            }); 
            RuleSet("UpdateBook", () =>
            {
                RuleFor(x => x.Id).NotEmpty().WithMessage("Id must be empty or null");
                RuleFor(x => x.Title).MustAsync((async (title, token) => (await service.ExistsAsync(title).ConfigureAwait(false))));
            });

            RuleFor(x => x.Title).NotEmpty().MaximumLength(20).MinimumLength(5);
            RuleFor(x => x.Price).GreaterThan(0.0);
        }
    }
}
