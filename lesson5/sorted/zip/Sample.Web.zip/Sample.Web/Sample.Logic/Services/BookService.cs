﻿using System.Collections.Generic;
using Sample.Data.Context;
using Sample.Models;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using FluentValidation;
using Sample.Logic.Services.Base;

namespace Sample.Logic.Services
{
    public class BookService : BaseService, IBookService
    {
        private readonly IValidator<Book> _validator;

        public BookService(BookContext context, IValidator<Book> validator) : base(context)
        {
            _validator = validator;
        }

        public Book GetById(string id)
        {
            var result = _context.Books.SingleOrDefault(x => x.Id == id);
            return result == null ? null : new Book() { Id = result.Id, Title = result.Title, Price = result.Price };
        }

        public async Task<Book> GetByIdAsync(string id)
        {
            var result = await _context.Books.SingleOrDefaultAsync(x => x.Id == id).ConfigureAwait(false);
            return result == null ? null : new Book() { Id = result.Id, Title = result.Title, Price = result.Price };
        }

        public async Task<IEnumerable<Book>> GetAllAsync()
        {
            return await _context.Books.Select(item => new Book()
            {
                Id = item.Id,
                Title = item.Title,
                Price = item.Price
            }).ToListAsync().ConfigureAwait(false);
        }

        public async Task<bool> ExistsAsync(string title)
        {
            return await _context.Books.AnyAsync(b => b.Title == title).ConfigureAwait(false);
        }
    }
}
