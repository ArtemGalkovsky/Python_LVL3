﻿using System;
using Sample.Data.Context;

namespace Sample.Logic.Services.Base
{
    public abstract class BaseService : IDisposable
    {
        protected readonly BookContext _context;
        private bool _isDisposed = false;

        protected BaseService(BookContext context)
        {
            _context = context;
        }

        public void Dispose()
        {
            this.Dispose(true);
            
        }

        protected void Dispose(bool flag)
        {
            if(_isDisposed) return;

            _context?.Dispose();
            _isDisposed = true;
            if(flag) GC.SuppressFinalize(this);
        }

        ~BaseService()
        {
            this.Dispose(false);
        }
    }
}