﻿using Sample.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Sample.Data.Models;

namespace Sample.Logic.Services
{
    public interface IBookService : IDisposable
    {
        Book GetById(string id);

        Task<Book> GetByIdAsync(string id);

        Task<IEnumerable<Book>> GetAllAsync();

        Task<bool> ExistsAsync(string title);
    }
}