﻿using Ninject.Modules;
using Sample.Logic.Services;
using Sample.Data;

namespace Sample.Logic
{
    public class LogicModule : NinjectModule
    {
        public override void Load()
        {
            Bind<IBookService>().To<BookService>();
            this.Kernel?.Load(new[] { new DataModule() });
        }
    }
}
